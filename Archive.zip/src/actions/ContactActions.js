import { CONTACT_UPDATE } from './constants';

export const contactUpdate = ({ prop, value }) => {
    return {
        type: CONTACT_UPDATE,
        payload: { prop, value }
    };
};