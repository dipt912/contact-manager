import { combineReducers } from 'redux';
import AuthReducer from './AuthReducer';
import ContactFormReducer, { CotactFormReducer } from './ContactFormReducer';

export default combineReducers({
   auth: AuthReducer,
   contactForm: ContactFormReducer
})