import React, { Component } from 'react';
import { Text, View } from 'react-native';
import { Card } from './common'

class ContactsList extends Component {
   render() {
       return (
           <Card>
                <Text> Contact1 </Text> 
                <Text> Contact1 </Text> 
                <Text> Contact1 </Text> 
                <Text> Contact1 </Text> 
                <Text> Contact1 </Text> 
                <Text> Contact1 </Text> 
                <Text> Contact1 </Text>    
           </Card>
       )
   }
}

export default ContactsList;