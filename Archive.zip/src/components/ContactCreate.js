import React, { Component } from 'react';
import { Picker, Text } from 'react-native';
import { Card, CardSection, Input, Button } from './common'
import { connect } from 'react-redux';
import { contactUpdate } from '../actions';

class ContactCreate extends Component {
    render() {
        return (
            <Card>
                <CardSection>
                    <Input
                        label='Name'
                        placeholder='Dipt Patel'
                        value={this.props.name}
                        onChangeText={value => this.props.contactUpdate({ prop: 'name', value })} />
                </CardSection>

                <CardSection>
                    <Input
                        label='Phone'
                        placeholder='555-555-5555'
                        value={this.props.phone}
                        onChangeText={value => this.props.contactUpdate({ prop: 'phone', value })} />
                </CardSection>
                <CardSection style={{ flexDirection: 'column'}}>
                    <Text style={styles.labelStyle}> Shift</Text>
                   <Picker
                      style ={{flex:1}}
                      selectedValue={this.props.shift}
                      onValueChange={day=> this.props.contactUpdate({props:'shift', day})}
                     > 
                       <Picker.Item lable='Monday' value='Monday'/>
                       <Picker.Item lable='Tuesday' value='Tuesday'/>
                       <Picker.Item lable='Wednesday' value='Wednesday'/>
                       <Picker.Item lable='Thursday' value='Thursday'/>
                       <Picker.Item lable='Friday' value='Friday'/>
                       <Picker.Item lable='Saturday' value='Saturday'/>
                       <Picker.Item lable='Sunday' value='Sunday'/>
                   </Picker>
                </CardSection>

                <CardSection>
                    <Button text='create' />
                </CardSection>

            </Card>
        )
    }
}

const styles = {
    labelStyle: {
        fontSize: 18,
        paddingLeft: 20
    }
}

const mapStateToProps = (state) => {
    const { name, phone, shift } = state.contactForm;
    return {
        name, phone, shift
    }
}

export default connect(mapStateToProps, { contactUpdate })(ContactCreate);